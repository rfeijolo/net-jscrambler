﻿// this a test js file
var test = true;
